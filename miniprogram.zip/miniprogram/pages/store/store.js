// pages/store/store.js
const db = wx.cloud.database()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userIntegral:3425,
    specialGoodsArr: null,
    lifeGoodsArr: null,
    othersGoodsArr: null
  },

  onGetIntegral(e){
    console.log('onGetIntegral', e)
  },

  onStore(event){
    let storeDetails = event.currentTarget.dataset.item
    let {goodsImg, title, integral} = storeDetails
    let userIntegral = this.data.userIntegral
    let storeIntegral = integral

    wx.navigateTo({
      url:`./storeDetails/storeDetails?goodsImg=${goodsImg}&title=${title}&storeIntegral=${storeIntegral}&userIntegral=${userIntegral}`
    })
  },

  onSwitchGoods(event) {
    let title = event.detail.title
    if (title === '生活用品') {
      db.collection('lifeGoods').get().then(res => {
        this.setData({
          lifeGoodsArr: res.data
        })
      })
    } else if (title === '其他商品') {
      db.collection('othersGoods').get().then(res => {
        this.setData({
          othersGoodsArr: res.data
        })
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    db.collection('specialGoods').get().then(res => {
      this.setData({
        specialGoodsArr: res.data
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
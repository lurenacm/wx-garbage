// pages/science/science.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据 
   */

  data: {
    reConceptArr: null,
    iconArr: null,
    kitchenArr: null,
    kitchenIconArr:null,
    harmfulConcept:null,
    harmfulIconArr:null,
    residualConcept:null,
    residualIconArr: null
  },

  async onSwitch(event) {
    let title = event.detail.title
    let concept = null
    let iconsData = null

    if (title === '厨余垃圾') {
    //  let res = await Promise.all([this.requestConcept('kitchenConcept'), this.requestIconsData('kitchenIcon')])
    //  console.log('res promise.all', res)
  
      concept = await this.requestConcept('kitchenConcept')
      iconsData = await this.requestIconsData('kitchenIcon')
      this.setData({
        kitchenArr: concept,
        kitchenIconArr: iconsData
      })

    } else if (title === '有害垃圾') {
      concept = await this.requestConcept('harmfulConcept')
      iconsData = await this.requestIconsData('harmfulIcon')
      this.setData({
        harmfulConcept: concept,
        harmfulIconArr: iconsData
      })

    } else if (title === '其他垃圾') {
      concept = await this.requestConcept('residualConcept')
      iconsData = await this.requestIconsData('residualIcon')
      this.setData({
        residualConcept: concept,
        residualIconArr: iconsData
      })
    }
  },


  requestConcept(dataName) {
    return db.collection(dataName).get().then(res => {
      return res.data[0]
    })
  },

  requestIconsData(dataName){
    return db.collection(dataName).get().then(res => {
      return res.data
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    db.collection('recyclableConcept').get().then(res => {
      this.setData({
        reConceptArr: res.data[0]
      })
    })

    db.collection('recyclableIcon').get().then(res => {
      this.setData({
        iconArr: res.data
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
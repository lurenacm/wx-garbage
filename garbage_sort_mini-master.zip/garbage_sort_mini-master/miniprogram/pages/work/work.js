// miniprogram/pages/work/work.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    banner: [],
    daan: 1,
    work: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //调用数据库
    const db = wx.cloud.database()
    const banner = db.collection('fenleibanner')
    banner.get().then(res => {
      console.log(res)
      this.setData({
        banner: res.data
      })
    })
      .catch(err => {
        console.log(err)
      })

    const work = db.collection('work')
    work.get({
      success(res) {
        this.setData({
          work: res.data
        })
        console.log(res.data)
      },
      fail(err) {
        console.log(err)
      }
    })

  },

  clickNum: function (e) {
    // console.log(typeof parseInt(this.daan))
    // console.log(typeof parseInt(e.target.dataset.num))
    // console.log(parseInt(e.target.dataset.num))
    // console.log(parseInt(this.data.daan))
    if (parseInt(e.target.dataset.num) == parseInt(this.data.daan)) {
      wx.showToast({
        title: '回答正确',
        icon: 'success',
        duration: 2000
      })
    }
    else {
      wx.showToast({
        title: '回答错误',
        icon: 'none',
        duration: 2000
      })
    }

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})